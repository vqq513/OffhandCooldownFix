package com.example.offhandcooldownfix.listener;

import io.papermc.paper.event.player.PlayerArmSwingEvent;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.inventory.EquipmentSlot;

public final class OffhandSwingListener implements Listener {

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onArmSwing(PlayerArmSwingEvent event) {
        if (event.getHand() == EquipmentSlot.OFF_HAND) {
            event.setCancelled(true);
        }
    }
}