package com.example.offhandcooldownfix;

import com.example.offhandcooldownfix.listener.OffhandSwingListener;
import org.bukkit.plugin.java.JavaPlugin;

public final class OffhandCooldownFix extends JavaPlugin {

    @Override
    public void onEnable() {
        getServer().getPluginManager().registerEvents(
                new OffhandSwingListener(),
                this
        );

        getLogger().info("OffhandCooldownFix enabled!");
    }

    @Override
    public void onDisable() {
        getLogger().info("OffhandCooldownFix disabled!");
    }
}